#
# TABLE STRUCTURE FOR: account
#

DROP TABLE IF EXISTS account;

CREATE TABLE `account` (
  `accountid` int(100) NOT NULL AUTO_INCREMENT,
  `refid` int(30) NOT NULL,
  `oriamount` double(10,2) NOT NULL,
  `amount` double(10,2) NOT NULL,
  `totalamount` double(15,2) NOT NULL,
  `customerid` int(30) NOT NULL,
  `datee` date NOT NULL,
  `interest` double(30,2) NOT NULL,
  `duedate` date NOT NULL,
  `packageid` int(30) NOT NULL,
  `agentid` int(30) NOT NULL,
  `packagetypeid` int(30) NOT NULL,
  `status` text NOT NULL,
  `companyid` int(30) NOT NULL,
  `guarantyitem` text NOT NULL,
  `agentcharge` double(30,2) NOT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (1, 1, '650.00', '200.00', '300.00', 1, '2018-08-21', '100.00', '2018-08-28', 1, 0, 1, 'late', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (2, 1, '650.00', '150.00', '150.00', 1, '2018-08-28', '0.00', '2018-09-04', 1, 0, 1, '', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (3, 1, '650.00', '150.00', '150.00', 1, '2018-09-04', '0.00', '2018-09-11', 1, 0, 1, '', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (4, 1, '650.00', '150.00', '150.00', 1, '2018-09-11', '0.00', '2018-09-18', 1, 0, 1, '', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (5, 2, '650.00', '200.00', '650.00', 2, '2018-08-14', '450.00', '2018-08-21', 1, 0, 1, 'late', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (6, 2, '650.00', '150.00', '250.00', 2, '2018-08-21', '100.00', '2018-08-28', 1, 0, 1, 'late', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (7, 2, '650.00', '150.00', '150.00', 2, '2018-08-28', '0.00', '2018-09-04', 1, 0, 1, '', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (8, 2, '650.00', '150.00', '150.00', 2, '2018-09-04', '0.00', '2018-09-11', 1, 0, 1, '', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (9, 3, '1250.00', '1250.00', '231323.93', 1, '2018-06-06', '235073.93', '2018-07-06', 1, 1, 2, 'late', 1, '', '3.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (10, 4, '650.00', '200.00', '5100.00', 1, '2018-05-16', '4900.00', '2018-05-23', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (11, 4, '650.00', '150.00', '4700.00', 1, '2018-05-23', '4550.00', '2018-05-30', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (12, 4, '650.00', '150.00', '4350.00', 1, '2018-05-30', '4200.00', '2018-06-06', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (13, 4, '650.00', '150.00', '4000.00', 1, '2018-06-06', '3850.00', '2018-06-13', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (14, 5, '650.00', '200.00', '11400.00', 1, '2018-01-10', '11200.00', '2018-01-17', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (15, 5, '650.00', '150.00', '11000.00', 1, '2018-01-17', '10850.00', '2018-01-24', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (16, 5, '650.00', '150.00', '10650.00', 1, '2018-01-24', '10500.00', '2018-01-31', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (17, 5, '650.00', '150.00', '10300.00', 1, '2018-01-31', '10150.00', '2018-02-07', 1, 0, 1, 'baddebt', 1, '', '0.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (18, 6, '1200.00', '1200.00', '1200.00', 1, '2018-08-30', '0.00', '2018-09-06', 1, 1, 3, '', 1, '', '3.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (19, 7, '650.00', '200.00', '650.00', 1, '2018-08-14', '450.00', '2018-08-21', 1, 1, 1, 'late', 1, '', '3.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (20, 7, '650.00', '150.00', '250.00', 1, '2018-08-21', '100.00', '2018-08-28', 1, 1, 1, 'late', 1, '', '3.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (21, 7, '650.00', '150.00', '150.00', 1, '2018-08-28', '0.00', '2018-09-04', 1, 1, 1, '', 1, '', '3.00');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`) VALUES (22, 7, '650.00', '150.00', '150.00', 1, '2018-09-04', '0.00', '2018-09-11', 1, 1, 1, '', 1, '', '3.00');


#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS admin;

CREATE TABLE `admin` (
  `adminid` int(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` tinytext NOT NULL,
  `campany` varchar(50) NOT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO admin (`adminid`, `username`, `password`, `campany`) VALUES (1, 'admin', 'admin', 'admin');
INSERT INTO admin (`adminid`, `username`, `password`, `campany`) VALUES (2, 'frezzy96', '01325214', 'FrezzyCompany');
INSERT INTO admin (`adminid`, `username`, `password`, `campany`) VALUES (3, 'frezzy1', '01325214', 'MoneyX');


#
# TABLE STRUCTURE FOR: agent
#

DROP TABLE IF EXISTS agent;

CREATE TABLE `agent` (
  `agentid` int(100) NOT NULL AUTO_INCREMENT,
  `agentname` varchar(100) NOT NULL,
  `charge` double(10,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  `salary` double(30,2) NOT NULL,
  PRIMARY KEY (`agentid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO agent (`agentid`, `agentname`, `charge`, `companyid`, `salary`) VALUES (1, 'A Wong2', '3.00', 1, '0.00');


#
# TABLE STRUCTURE FOR: agentpayment
#

DROP TABLE IF EXISTS agentpayment;

CREATE TABLE `agentpayment` (
  `paymentid` int(30) NOT NULL AUTO_INCREMENT,
  `agentid` int(30) NOT NULL,
  `payment` double(30,2) NOT NULL,
  `paymentdate` date NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: assistant
#

DROP TABLE IF EXISTS assistant;

CREATE TABLE `assistant` (
  `assisid` int(6) NOT NULL AUTO_INCREMENT,
  `assisname` varchar(50) NOT NULL,
  `customerid` int(6) NOT NULL,
  `charge` varchar(30) NOT NULL,
  `accountid` int(100) NOT NULL,
  `salary` double(10,2) NOT NULL,
  PRIMARY KEY (`assisid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: baddebt
#

DROP TABLE IF EXISTS baddebt;

CREATE TABLE `baddebt` (
  `baddebtid` int(100) NOT NULL AUTO_INCREMENT,
  `accountid` int(30) NOT NULL,
  `datee` date NOT NULL,
  PRIMARY KEY (`baddebtid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (1, 10, '2018-07-22');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (2, 11, '2018-07-29');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (3, 12, '2018-08-05');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (4, 13, '2018-08-12');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (5, 14, '2018-03-18');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (6, 15, '2018-03-25');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (7, 16, '2018-04-01');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (8, 17, '2018-04-08');


#
# TABLE STRUCTURE FOR: blacklist
#

DROP TABLE IF EXISTS blacklist;

CREATE TABLE `blacklist` (
  `blacklistid` int(6) NOT NULL AUTO_INCREMENT,
  `customername` varchar(50) NOT NULL,
  `address` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`blacklistid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: customer
#

DROP TABLE IF EXISTS customer;

CREATE TABLE `customer` (
  `customerid` int(6) NOT NULL AUTO_INCREMENT,
  `customername` varchar(50) NOT NULL,
  `address` varchar(300) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `phoneno` varchar(30) NOT NULL,
  `wechatname` text NOT NULL,
  `companyid` int(30) NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`customerid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`) VALUES (1, 'Lu Chow Ling2', '51, Jalan Setia 12/19, Taman Setia Indah, 81100 JB2', 'Male', '012 70081412', 'Lu.2', 1, '');


#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS employee;

CREATE TABLE `employee` (
  `employeeid` int(6) NOT NULL AUTO_INCREMENT,
  `employeename` varchar(50) NOT NULL,
  `salary` double(10,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  `contactnum` text NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO employee (`employeeid`, `employeename`, `salary`, `companyid`, `contactnum`) VALUES (6, 'tan', '720.00', 1, '0125588874');
INSERT INTO employee (`employeeid`, `employeename`, `salary`, `companyid`, `contactnum`) VALUES (5, 'qwq', '750.00', 1, '0155548879');


#
# TABLE STRUCTURE FOR: package_15_week
#

DROP TABLE IF EXISTS package_15_week;

CREATE TABLE `package_15_week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `guarantyitem` text NOT NULL,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `week1` double(30,2) NOT NULL,
  `week2` double(30,2) NOT NULL,
  `week3` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO package_15_week (`packageid`, `guarantyitem`, `lentamount`, `interest`, `totalamount`, `week1`, `week2`, `week3`, `companyid`) VALUES (1, '0', '1000.00', '50.00', '1150.00', '0.00', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: package_20_week
#

DROP TABLE IF EXISTS package_20_week;

CREATE TABLE `package_20_week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `week2` double(30,2) NOT NULL,
  `week3` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO package_20_week (`packageid`, `lentamount`, `interest`, `totalamount`, `week2`, `week3`, `companyid`) VALUES (1, '1000.00', '50.00', '1200.00', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: package_25_month
#

DROP TABLE IF EXISTS package_25_month;

CREATE TABLE `package_25_month` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO package_25_month (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (1, '1000.00', '10.00', '1250.00', 1);


#
# TABLE STRUCTURE FOR: package_30_4week
#

DROP TABLE IF EXISTS package_30_4week;

CREATE TABLE `package_30_4week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `week1` double(30,2) NOT NULL,
  `week2` double(30,2) NOT NULL,
  `week3` double(30,2) NOT NULL,
  `week4` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO package_30_4week (`packageid`, `lentamount`, `interest`, `totalamount`, `week1`, `week2`, `week3`, `week4`, `companyid`) VALUES (1, '500.00', '50.00', '650.00', '200.00', '150.00', '150.00', '150.00', 1);


#
# TABLE STRUCTURE FOR: packagetype
#

DROP TABLE IF EXISTS packagetype;

CREATE TABLE `packagetype` (
  `packagetypeid` int(11) NOT NULL AUTO_INCREMENT,
  `packagetypename` varchar(30) NOT NULL,
  PRIMARY KEY (`packagetypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (1, 'package_30_4week');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (2, 'package_25_month');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (3, 'package_20_week');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (4, 'package_15_week');


#
# TABLE STRUCTURE FOR: payment
#

DROP TABLE IF EXISTS payment;

CREATE TABLE `payment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `accountid` int(15) NOT NULL,
  `customername` text NOT NULL,
  `payment` double(10,2) NOT NULL,
  `paymenttype` text NOT NULL,
  `paymentdate` date NOT NULL,
  UNIQUE KEY `paymantid` (`paymentid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO payment (`paymentid`, `accountid`, `customername`, `payment`, `paymenttype`, `paymentdate`) VALUES (1, 9, '', '3000.00', 'amount', '2018-08-30');
INSERT INTO payment (`paymentid`, `accountid`, `customername`, `payment`, `paymenttype`, `paymentdate`) VALUES (2, 9, '', '2000.00', 'discount', '2018-08-30');


