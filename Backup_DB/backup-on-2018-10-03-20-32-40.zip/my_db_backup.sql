#
# TABLE STRUCTURE FOR: account
#

DROP TABLE IF EXISTS account;

CREATE TABLE `account` (
  `accountid` int(100) NOT NULL AUTO_INCREMENT,
  `refid` int(30) NOT NULL,
  `oriamount` double(10,2) NOT NULL,
  `amount` double(10,2) NOT NULL,
  `totalamount` double(15,2) NOT NULL,
  `customerid` int(30) NOT NULL,
  `datee` date NOT NULL,
  `interest` double(30,2) NOT NULL,
  `duedate` date NOT NULL,
  `packageid` int(30) NOT NULL,
  `agentid` int(30) NOT NULL,
  `packagetypeid` int(30) NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `companyid` int(30) NOT NULL,
  `guarantyitem` text COLLATE utf8_unicode_ci NOT NULL,
  `agentcharge` double(30,2) NOT NULL,
  `accountline` int(11) NOT NULL,
  `homeremind` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (1, 1, '1300.00', '350.00', '1700.00', 1, '2018-08-29', '1350.00', '2018-09-05', 3, 1, 1, 'baddebt', 2, '', '33.00', 1, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (2, 1, '1300.00', '350.00', '1350.00', 1, '2018-09-05', '1000.00', '2018-09-12', 3, 1, 1, 'baddebt', 2, '', '33.00', 1, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (3, 1, '1300.00', '300.00', '950.00', 1, '2018-09-12', '650.00', '2018-09-19', 3, 1, 1, 'baddebt', 2, '', '33.00', 1, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (4, 1, '1300.00', '300.00', '600.00', 1, '2018-09-19', '300.00', '2018-09-26', 3, 1, 1, 'baddebt', 2, '', '33.00', 1, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (5, 2, '1250.00', '350.00', '1800.00', 1, '2018-08-29', '1450.00', '2018-09-03', 3, 0, 9, 'late', 2, '', '0.00', 2, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (6, 2, '1250.00', '350.00', '1550.00', 1, '2018-09-03', '1200.00', '2018-09-08', 3, 0, 9, 'late', 2, '', '0.00', 2, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (7, 2, '1250.00', '350.00', '1300.00', 1, '2018-09-08', '950.00', '2018-09-13', 3, 0, 9, 'late', 2, '', '0.00', 2, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (8, 2, '1250.00', '200.00', '900.00', 1, '2018-09-13', '700.00', '2018-09-18', 3, 0, 9, 'late', 2, '', '0.00', 2, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (10, 3, '1400.00', '1400.00', '2350.00', 1, '2018-09-13', '950.00', '2018-09-13', 4, 0, 8, 'late', 2, '', '0.00', 3, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (11, 4, '625.00', '625.00', '2157.67', 1, '2018-09-06', '0.00', '2018-09-19', 2, 0, 2, 'late', 2, '', '0.00', 4, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (12, 5, '575.00', '575.00', '575.00', 1, '2018-09-18', '0.00', '2018-09-25', 2, 1, 4, 'late', 2, '0', '33.00', 5, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (13, 6, '575.00', '575.00', '575.00', 1, '2018-09-24', '0.00', '2018-10-01', 2, 0, 4, 'baddebt', 2, '0', '0.00', 6, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (14, 7, '1150.00', '1150.00', '1150.00', 1, '2018-09-24', '0.00', '2018-10-01', 3, 0, 4, '', 2, '0', '0.00', 7, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (15, 8, '575.00', '575.00', '575.00', 1, '2018-09-18', '0.00', '2018-09-25', 2, 1, 4, 'late', 2, '0', '33.00', 8, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (16, 9, '1300.00', '350.00', '400.00', 1, '2018-09-24', '50.00', '2018-10-01', 3, 1, 1, '', 2, '', '33.00', 9, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (17, 9, '1300.00', '350.00', '350.00', 1, '2018-10-01', '0.00', '2018-10-08', 3, 1, 1, '', 2, '', '33.00', 9, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (18, 9, '1300.00', '300.00', '300.00', 1, '2018-10-08', '0.00', '2018-10-15', 3, 1, 1, '', 2, '', '33.00', 9, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (19, 9, '1300.00', '300.00', '300.00', 1, '2018-10-15', '0.00', '2018-10-22', 3, 1, 1, '', 2, '', '33.00', 9, '');
INSERT INTO account (`accountid`, `refid`, `oriamount`, `amount`, `totalamount`, `customerid`, `datee`, `interest`, `duedate`, `packageid`, `agentid`, `packagetypeid`, `status`, `companyid`, `guarantyitem`, `agentcharge`, `accountline`, `homeremind`) VALUES (20, 10, '600.00', '600.00', '600.00', 1, '2018-09-23', '0.00', '2018-09-30', 3, 1, 3, '', 2, '', '33.00', 10, '');


#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS admin;

CREATE TABLE `admin` (
  `adminid` int(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `campany` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO admin (`adminid`, `username`, `password`, `campany`) VALUES (1, 'admin', 'admin', 'admin');
INSERT INTO admin (`adminid`, `username`, `password`, `campany`) VALUES (2, 'frezzy96', '01325214', 'FrezzyCompany');
INSERT INTO admin (`adminid`, `username`, `password`, `campany`) VALUES (3, 'frezzy1', '01325214', 'MoneyX');


#
# TABLE STRUCTURE FOR: agent
#

DROP TABLE IF EXISTS agent;

CREATE TABLE `agent` (
  `agentid` int(100) NOT NULL AUTO_INCREMENT,
  `agentname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `charge` double(10,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  `salary` double(30,2) NOT NULL,
  PRIMARY KEY (`agentid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO agent (`agentid`, `agentname`, `charge`, `companyid`, `salary`) VALUES (1, 'Agent A', '33.00', 2, '0.00');
INSERT INTO agent (`agentid`, `agentname`, `charge`, `companyid`, `salary`) VALUES (2, '老明', '12.00', 2, '0.00');


#
# TABLE STRUCTURE FOR: agentpayment
#

DROP TABLE IF EXISTS agentpayment;

CREATE TABLE `agentpayment` (
  `paymentid` int(30) NOT NULL AUTO_INCREMENT,
  `agentid` int(30) NOT NULL,
  `payment` double(30,2) NOT NULL,
  `paymentdate` date NOT NULL,
  `refid` int(30) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: assistant
#

DROP TABLE IF EXISTS assistant;

CREATE TABLE `assistant` (
  `assisid` int(6) NOT NULL AUTO_INCREMENT,
  `assisname` varchar(50) CHARACTER SET latin1 NOT NULL,
  `customerid` int(6) NOT NULL,
  `charge` varchar(30) CHARACTER SET latin1 NOT NULL,
  `accountid` int(100) NOT NULL,
  `salary` double(10,2) NOT NULL,
  PRIMARY KEY (`assisid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: baddebt
#

DROP TABLE IF EXISTS baddebt;

CREATE TABLE `baddebt` (
  `baddebtid` int(100) NOT NULL AUTO_INCREMENT,
  `accountid` int(30) NOT NULL,
  `datee` date NOT NULL,
  PRIMARY KEY (`baddebtid`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (1, 2, '1970-03-02');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (2, 3, '1970-03-02');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (3, 4, '1970-03-02');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (4, 5, '1970-03-02');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (5, 6, '2018-06-17');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (6, 7, '2018-07-09');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (7, 8, '2018-04-12');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (8, 9, '2018-04-19');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (9, 10, '2018-04-26');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (10, 11, '2018-05-03');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (11, 12, '2018-06-11');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (12, 14, '2018-08-15');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (13, 29, '2018-03-09');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (14, 30, '2018-03-09');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (15, 31, '2018-02-09');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (16, 32, '2018-02-09');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (17, 33, '2018-02-09');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (18, 34, '2018-03-18');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (19, 35, '2018-03-18');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (20, 1, '2018-06-17');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (21, 13, '2018-10-03');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (22, 15, '2018-10-17');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (23, 16, '2018-10-24');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (24, 21, '2018-10-01');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (25, 22, '2018-10-06');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (26, 23, '2018-10-11');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (27, 24, '2018-10-16');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (28, 25, '2018-08-25');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (29, 26, '2018-08-30');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (30, 27, '2018-09-04');
INSERT INTO baddebt (`baddebtid`, `accountid`, `datee`) VALUES (31, 28, '2018-09-09');


#
# TABLE STRUCTURE FOR: bank
#

DROP TABLE IF EXISTS bank;

CREATE TABLE `bank` (
  `bookid` int(30) NOT NULL AUTO_INCREMENT,
  `bank` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `amount` double(15,2) NOT NULL,
  `datee` date NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: blacklist
#

DROP TABLE IF EXISTS blacklist;

CREATE TABLE `blacklist` (
  `blacklistid` int(6) NOT NULL AUTO_INCREMENT,
  `customerid` int(6) NOT NULL,
  PRIMARY KEY (`blacklistid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: coh
#

DROP TABLE IF EXISTS coh;

CREATE TABLE `coh` (
  `bookid` int(30) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `amount` double(15,2) NOT NULL,
  `datee` date NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: customer
#

DROP TABLE IF EXISTS customer;

CREATE TABLE `customer` (
  `customerid` int(6) NOT NULL AUTO_INCREMENT,
  `customername` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `phoneno` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `wechatname` text COLLATE utf8_unicode_ci NOT NULL,
  `companyid` int(30) NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `passport` text COLLATE utf8_unicode_ci NOT NULL,
  `photopath` text COLLATE utf8_unicode_ci NOT NULL,
  `blacklist` int(11) NOT NULL,
  `reset` int(15) NOT NULL,
  `re-date` date NOT NULL,
  PRIMARY KEY (`customerid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (1, 'Lu Chow Ling', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Male', '127008141', 'Lu', 2, 'good', '123', '', 0, 1, '2018-10-02');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (2, '???', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Female', '127008141', '?', 2, 'good', '123', '', 0, 1, '2018-10-02');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (3, '?', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Male', '127008141', 'Lu', 2, 'good', '9999999', '', 0, 0, '0000-00-00');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (4, '?', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Female', '127008141', 'Lu', 2, 'good', '12', '', 0, 0, '0000-00-00');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (5, '?', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Male', '127008141', 'Lu', 2, 'good', 'A012225eee', '', 0, 0, '0000-00-00');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (6, '其', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Male', '127008141', 'Lu', 2, 'good', '12', '', 0, 0, '0000-00-00');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (7, '额', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Male', '127008141', 'Lu', 2, 'good', '9999999', '', 0, 0, '0000-00-00');
INSERT INTO customer (`customerid`, `customername`, `address`, `gender`, `phoneno`, `wechatname`, `companyid`, `status`, `passport`, `photopath`, `blacklist`, `reset`, `re-date`) VALUES (8, 'Lu Chow Ling', '51, Jalan Setia 12/19, Taman Setia Indah,', 'Male', '127008141', 'Lu', 2, 'good', '123', '', 0, 0, '0000-00-00');


#
# TABLE STRUCTURE FOR: dbbackup
#

DROP TABLE IF EXISTS dbbackup;

CREATE TABLE `dbbackup` (
  `backupid` int(30) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  PRIMARY KEY (`backupid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO dbbackup (`backupid`, `date`) VALUES (1, '2018-09-19');
INSERT INTO dbbackup (`backupid`, `date`) VALUES (2, '2018-09-26');


#
# TABLE STRUCTURE FOR: emp
#

DROP TABLE IF EXISTS emp;

CREATE TABLE `emp` (
  `bookid` int(30) NOT NULL AUTO_INCREMENT,
  `employee` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `amount` double(15,2) NOT NULL,
  `datee` date NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS employee;

CREATE TABLE `employee` (
  `employeeid` int(6) NOT NULL AUTO_INCREMENT,
  `employeename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary` double(10,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  `contactnum` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO employee (`employeeid`, `employeename`, `salary`, `companyid`, `contactnum`) VALUES (1, 'Liu2', '222.00', 2, '222222222222');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `expensesid` int(30) NOT NULL AUTO_INCREMENT,
  `expensesitem` text COLLATE utf8_unicode_ci NOT NULL,
  `expensesfee` double(30,2) NOT NULL,
  `expensesdate` date NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`expensesid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO expenses (`expensesid`, `expensesitem`, `expensesfee`, `expensesdate`, `companyid`) VALUES (1, 'Fuels', '123.00', '2018-09-25', 2);
INSERT INTO expenses (`expensesid`, `expensesitem`, `expensesfee`, `expensesdate`, `companyid`) VALUES (8, '123', '100.00', '2018-09-26', 2);
INSERT INTO expenses (`expensesid`, `expensesitem`, `expensesfee`, `expensesdate`, `companyid`) VALUES (9, '456', '150.00', '2018-09-26', 2);
INSERT INTO expenses (`expensesid`, `expensesitem`, `expensesfee`, `expensesdate`, `companyid`) VALUES (10, '789', '75.00', '2018-09-26', 2);


#
# TABLE STRUCTURE FOR: package_10_5days
#

DROP TABLE IF EXISTS package_10_5days;

CREATE TABLE `package_10_5days` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_10_5days (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (5, '1000.00', '50.00', '1100.00', 1);
INSERT INTO package_10_5days (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (6, '2000.00', '100.00', '2200.00', 2);


#
# TABLE STRUCTURE FOR: package_15_5days
#

DROP TABLE IF EXISTS package_15_5days;

CREATE TABLE `package_15_5days` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_15_5days (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (5, '1000.00', '50.00', '1150.00', 1);
INSERT INTO package_15_5days (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (6, '2000.00', '100.00', '2300.00', 2);


#
# TABLE STRUCTURE FOR: package_15_week
#

DROP TABLE IF EXISTS package_15_week;

CREATE TABLE `package_15_week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_15_week (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (2, '500.00', '50.00', '575.00', 2);
INSERT INTO package_15_week (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (3, '1000.00', '75.00', '1150.00', 2);
INSERT INTO package_15_week (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (4, '2000.00', '100.00', '2300.00', 2);


#
# TABLE STRUCTURE FOR: package_20_week
#

DROP TABLE IF EXISTS package_20_week;

CREATE TABLE `package_20_week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_20_week (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (3, '500.00', '50.00', '600.00', 2);
INSERT INTO package_20_week (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (4, '1000.00', '75.00', '1200.00', 2);


#
# TABLE STRUCTURE FOR: package_25_month
#

DROP TABLE IF EXISTS package_25_month;

CREATE TABLE `package_25_month` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_25_month (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`) VALUES (2, '500.00', '10.00', '625.00', 2);


#
# TABLE STRUCTURE FOR: package_30_4week
#

DROP TABLE IF EXISTS package_30_4week;

CREATE TABLE `package_30_4week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `week1` double(30,2) NOT NULL,
  `week2` double(30,2) NOT NULL,
  `week3` double(30,2) NOT NULL,
  `week4` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_30_4week (`packageid`, `lentamount`, `interest`, `totalamount`, `week1`, `week2`, `week3`, `week4`, `companyid`) VALUES (3, '1000.00', '50.00', '1300.00', '350.00', '350.00', '300.00', '300.00', 2);


#
# TABLE STRUCTURE FOR: package_manual_5days_4week
#

DROP TABLE IF EXISTS package_manual_5days_4week;

CREATE TABLE `package_manual_5days_4week` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `week1` double(30,2) NOT NULL,
  `week2` double(30,2) NOT NULL,
  `week3` double(30,2) NOT NULL,
  `week4` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_manual_5days_4week (`packageid`, `lentamount`, `interest`, `totalamount`, `week1`, `week2`, `week3`, `week4`, `companyid`) VALUES (3, '1000.00', '50.00', '1250.00', '350.00', '350.00', '350.00', '200.00', 2);
INSERT INTO package_manual_5days_4week (`packageid`, `lentamount`, `interest`, `totalamount`, `week1`, `week2`, `week3`, `week4`, `companyid`) VALUES (4, '2000.00', '100.00', '2500.00', '1000.00', '1000.00', '250.00', '250.00', 2);


#
# TABLE STRUCTURE FOR: package_manual_payeveryday_manualdays
#

DROP TABLE IF EXISTS package_manual_payeveryday_manualdays;

CREATE TABLE `package_manual_payeveryday_manualdays` (
  `packageid` int(30) NOT NULL AUTO_INCREMENT,
  `lentamount` double(30,2) NOT NULL,
  `interest` double(30,2) NOT NULL,
  `totalamount` double(30,2) NOT NULL,
  `companyid` int(30) NOT NULL,
  `days` int(30) NOT NULL,
  `amounteveryday` double(30,2) NOT NULL,
  PRIMARY KEY (`packageid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO package_manual_payeveryday_manualdays (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`, `days`, `amounteveryday`) VALUES (4, '1000.00', '50.00', '1400.00', 2, 20, '70.00');
INSERT INTO package_manual_payeveryday_manualdays (`packageid`, `lentamount`, `interest`, `totalamount`, `companyid`, `days`, `amounteveryday`) VALUES (5, '2000.00', '100.00', '2500.00', 2, 50, '50.00');


#
# TABLE STRUCTURE FOR: packagetype
#

DROP TABLE IF EXISTS packagetype;

CREATE TABLE `packagetype` (
  `packagetypeid` int(11) NOT NULL AUTO_INCREMENT,
  `packagetypename` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`packagetypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (1, 'package_30_4week');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (2, 'package_25_month');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (3, 'package_20_week');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (4, 'package_15_week');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (5, 'package_10_5days');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (6, 'package_15_5days');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (8, 'package_manual_payeveryday_manualdays');
INSERT INTO packagetype (`packagetypeid`, `packagetypename`) VALUES (9, 'package_manual_5days_4week');


#
# TABLE STRUCTURE FOR: payment
#

DROP TABLE IF EXISTS payment;

CREATE TABLE `payment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `accountid` int(15) NOT NULL,
  `customername` text COLLATE utf8_unicode_ci NOT NULL,
  `payment` double(10,2) NOT NULL,
  `paymenttype` text COLLATE utf8_unicode_ci NOT NULL,
  `paymentdate` date NOT NULL,
  UNIQUE KEY `paymantid` (`paymentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: total
#

DROP TABLE IF EXISTS total;

CREATE TABLE `total` (
  `bookid` int(30) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `amount` double(15,2) NOT NULL,
  `datee` date NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

